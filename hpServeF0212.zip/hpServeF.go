// https://medium.com/@mlowicki/http-s-proxy-in-golang-in-less-than-100-lines-of-code-6a51c2f2c38c
package main

import (
	"encoding/base64"
	"flag"
	"io"
	"log"
	"net"
	"net/http"
	"time"

	"github.com/valyala/fasthttp"
)

const secretlink = "zhima.kaimen"

var userPass string

//const unauth = http.StatusProxyAuthRequired
const unauth = http.StatusUnauthorized

func selfAuth(ctx *fasthttp.RequestCtx) bool {
	auth := string(ctx.Request.Header.Peek("Proxy-Authorization"))
	if (auth == "") || (auth[0:6] != "Basic ") {
		if string(ctx.Request.Host()) == secretlink {
			ctx.Response.Header.Set("Proxy-Authenticate", "Basic realm=\"Caddy Secure Web Proxy\"")
			ctx.Response.Header.SetStatusCode(http.StatusProxyAuthRequired)
		}
		return false
	}
	if auth[6:] != userPass {
		return false
	}
	return true
}

func handleTunneling(ctx *fasthttp.RequestCtx) {
	destConn, err := fasthttp.DialTimeout(string(ctx.Request.Host()), 10*time.Second)
	if err != nil {
		return
	}
	hijackHandler := func(clientConn net.Conn) {
		errc := make(chan error, 1)
		go transfer(errc, destConn, clientConn)
		go transfer(errc, clientConn, destConn)
		<-errc
		return
	}
	ctx.Hijack(hijackHandler)
}

func transfer(errc chan<- error, destination io.WriteCloser, source io.ReadCloser) {
	defer destination.Close()
	defer source.Close()
	_, err := io.Copy(destination, source)
	errc <- err
}

func handleHTTP(ctx *fasthttp.RequestCtx) {
	fasthttp.DoRedirects(&ctx.Request, &ctx.Response, 10)
}

func requestHandler(ctx *fasthttp.RequestCtx) {
	if !selfAuth(ctx) {
		return
	}
	if string(ctx.Method()) == "CONNECT" {
		handleTunneling(ctx)
	} else {
		handleHTTP(ctx)
	}
}

var (
	pemPath    = flag.String("pem", "server.pem", "path to pem file")
	keyPath    = flag.String("key", "server.key", "path to key file")
	proto      = flag.String("proto", "https", "Proxy protocol (http or https)")
	userPassIn = flag.String("userpass", "null", "username:password (len>5)")
	ipaddr     = flag.String("ipaddr", "", "Proxy ipaddr(default:)")
	port       = flag.String("port", "8888", "Proxy port(default: 8888)")
)

func main() {
	flag.Parse()
	if len(*userPassIn) > 5 {
		userPass = string(base64.URLEncoding.EncodeToString([]byte(*userPassIn)))
	} else {
		userPass = string(base64.URLEncoding.EncodeToString([]byte("neo:5b73add1")))
	}
	if *proto != "http" && *proto != "https" {
		log.Fatal("Protocol must be either http or https")
	}
	h := requestHandler
	if *proto == "http" {
		if err := fasthttp.ListenAndServe(*ipaddr+":"+*port, h); err != nil {
			log.Fatalf("Error in ListenAndServe: %s", err)
		}
	} else {
		if err := fasthttp.ListenAndServeTLS(*ipaddr+":"+*port, *pemPath, *keyPath, h); err != nil {
			log.Fatalf("Error in ListenAndServeTLS: %s", err)
		}
	}
}
